module clk_div_100hz(input clk50hz,
                    input rst,
                     output clk_out);
  reg[18:0]count;
  always@(posedge clk50hz or posedge rst)begin
    if(rst)begin
      count<=0;
      clk_out=0;
    end
    else
      if(counter==249999)begin
        count<=0;
        clk_out<=~clk_out;
      end
    else
      count<=count+1;
  end
endmodule
